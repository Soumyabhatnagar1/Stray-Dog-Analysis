# Stray Dog Management – Data Analytics (Excel, Python, SQL, Power BI)

This package contains a full, working analytics project:

## Folder Structure
```
StrayDogAnalytics_Project/
├─ data/
│  ├─ dim_state.csv
│  ├─ dim_city.csv
│  └─ fact_city_month.csv
├─ excel/
│  └─ StrayDogAnalytics.xlsx
├─ notebooks/
│  └─ StrayDog_Analytics.ipynb
├─ powerbi/
│  ├─ StrayDog_DataFolder.pbids
│  ├─ PowerQuery_LoadCsvs.m.txt
│  └─ DAX_Measures.txt
└─ sql/
   ├─ stray_dog_schema_mysql.sql
   └─ stray_dog.sqlite
```

## How to Use

### 1) MySQL (or MariaDB)
- Open `sql/stray_dog_schema_mysql.sql` in your MySQL client.
- Run it to create the `stray_dog_analytics` database, tables, and load all data.

### 2) SQLite (instant SQL)
- Open `sql/stray_dog.sqlite` in any SQLite browser or from Python.
- Same tables and data are preloaded.

### 3) Python (Jupyter Notebook)
- Open `notebooks/StrayDog_Analytics.ipynb` in Jupyter.
- The notebook loads CSVs, runs exploratory analysis & SQL queries on SQLite, and generates charts with matplotlib.

### 4) Excel
- Open `excel/StrayDogAnalytics.xlsx`.
- Sheets:
  - `FactCityMonth`, `DimCity`, `DimState` (raw data)
  - `StateMonthlyAgg` (pre-aggregated with a line chart)
  - `NationMonthly` (column chart comparing bites vs sterilizations)
- Create more PivotTables and charts as needed.

### 5) Power BI
- Double-click `powerbi/StrayDog_DataFolder.pbids` to open Power BI and point to the `data/` folder.
- In Power Query (Transform Data → Advanced Editor), paste the M code from `powerbi/PowerQuery_LoadCsvs.m.txt` to load the three tables.
- Create model relationships:
  - `dim_state[state_id]` → `fact_city_month[state_id]`
  - `dim_city[city_id]` → `fact_city_month[city_id]`
- Add DAX measures from `powerbi/DAX_Measures.txt` and build visuals:
  - Cards: **Total Bites**, **Vaccination Rate**, **Sterilization Rate**
  - Line chart: Bites over time by State
  - Clustered column: Bites vs Sterilizations by Month
  - Map: Bites by City (use city & state columns)
  - Slicers: State, City, Year, Month

### Notes
- All files use consistent keys (`state_id`, `city_id`, `date`).
- The `SQLite` DB is for quick demos; `MySQL` script is provided for production-like use.
- Power BI `.pbix` cannot be programmatically generated here, but the `.pbids` + M script + DAX get you the same report quickly.